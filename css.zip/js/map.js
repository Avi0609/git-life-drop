/**
 * LIFEDROP - INTERACTIVE MAP ENGINE (js/map.js)
 * Full Interactive Mapping for Blood Banks, Donors & Requesters across Jharkhand
 */

const MapEngine = {
  map: null,
  centersLayer: null,
  donorsLayer: null,
  requestsLayer: null,
  campsLayer: null,
  userLayer: null,
  userMarker: null,
  userCoords: null, // { lat, lng, city, locality }

  // Jharkhand City Anchors
  jharkhandCities: {
    'all': { lat: 23.6102, lng: 85.5000, zoom: 8, name: 'All Jharkhand' },
    'ranchi': { lat: 23.3685, lng: 85.3340, zoom: 13, name: 'Ranchi' },
    'bokaro': { lat: 23.6693, lng: 86.1511, zoom: 13, name: 'Bokaro Steel City' },
    'jamshedpur': { lat: 22.8028, lng: 86.1854, zoom: 13, name: 'Jamshedpur' },
    'ramgarh': { lat: 23.6310, lng: 85.5180, zoom: 14, name: 'Ramgarh' },
    'deoghar': { lat: 24.4920, lng: 86.7020, zoom: 13, name: 'Deoghar' },
    'hazaribagh': { lat: 23.9960, lng: 85.3620, zoom: 14, name: 'Hazaribagh' }
  },

  async init() {
    const container = document.getElementById('bloodMap');
    if (!container) return;

    if (typeof L === 'undefined') {
      container.innerHTML = `
        <div style="padding:40px; text-align:center; background:#fff; height:100%; display:grid; place-items:center;">
          <p style="font-weight:700; color:var(--primary);">🗺️ Map engine initialized. (Using local fallback points)</p>
        </div>
      `;
      return;
    }

    // Default: Center of Jharkhand (Ranchi / Ramgarh region)
    const initial = this.jharkhandCities['all'];
    this.map = L.map('bloodMap').setView([initial.lat, initial.lng], initial.zoom);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '© OpenStreetMap contributors | LifeDrop Jharkhand'
    }).addTo(this.map);

    this.centersLayer = L.layerGroup().addTo(this.map);
    this.donorsLayer = L.layerGroup().addTo(this.map);
    this.requestsLayer = L.layerGroup().addTo(this.map);
    this.campsLayer = L.layerGroup().addTo(this.map);
    this.userLayer = L.layerGroup().addTo(this.map);

    // Plot all initial records
    await this.loadAllMapData();
  },

  async loadAllMapData() {
    await this.plotCenters();
    await this.plotDonors();
    await this.plotRequests();
    await this.plotCamps();
  },

  async plotCenters() {
    try {
      const res = await fetch('/api/centers');
      const data = await res.json();
      if (data.success && data.centers) {
        this.centersLayer.clearLayers();
        data.centers.forEach(c => {
          if (c.latitude && c.longitude) {
            const icon = L.divIcon({
              className: 'custom-map-icon',
              html: `<div class="custom-marker marker-bank" title="${c.name}">🏥</div>`,
              iconSize: [34, 34],
              iconAnchor: [17, 17]
            });

            const marker = L.marker([c.latitude, c.longitude], { icon });
            let distText = '';
            if (this.userCoords) {
              const km = this.calcDistance(this.userCoords.lat, this.userCoords.lng, c.latitude, c.longitude);
              distText = `<div style="color:var(--primary); font-size:12px; font-weight:700;">🧭 ~${km.toFixed(1)} km from your location</div>`;
            }

            const popup = `
              <div style="min-width:210px; font-family:inherit;">
                <div style="font-size:11px; font-weight:800; color:var(--primary); text-transform:uppercase;">🏥 Certified Blood Bank</div>
                <h4 style="font-size:15px; margin:3px 0 6px; font-weight:800;">${c.name}</h4>
                <div style="font-size:12px; color:var(--muted); margin-bottom:6px;">📍 ${c.locality}, ${c.city}</div>
                ${distText}
                <div style="font-size:12px; margin:6px 0;"><strong>🕒 Operating:</strong> ${c.operating_hours || '24/7'}</div>
                <div style="display:flex; gap:6px; margin-top:8px;">
                  <a href="tel:${c.phone}" class="btn btn-primary btn-sm" style="flex:1; text-align:center;">📞 Call</a>
                  <a href="https://www.google.com/maps/dir/?api=1&destination=${c.latitude},${c.longitude}" target="_blank" class="btn btn-outline btn-sm">🧭 Maps</a>
                </div>
              </div>
            `;
            marker.bindPopup(popup);
            this.centersLayer.addLayer(marker);
          }
        });
      }
    } catch (e) {
      console.warn('Map centers loading issue:', e);
    }
  },

  async plotDonors() {
    try {
      const res = await fetch('/api/donors');
      const data = await res.json();
      if (data.success && data.donors) {
        this.donorsLayer.clearLayers();
        data.donors.forEach(d => {
          if (d.latitude && d.longitude) {
            const icon = L.divIcon({
              className: 'custom-map-icon',
              html: `<div class="custom-marker marker-donor" title="Donor: ${d.name} (${d.blood_group})">${d.blood_group}</div>`,
              iconSize: [30, 30],
              iconAnchor: [15, 15]
            });

            const marker = L.marker([d.latitude, d.longitude], { icon });
            const isSuspicious = d.suspicious_reports_count > 0;
            const flagNotice = isSuspicious 
              ? `<div style="background:#fee2e2; color:#b91c1c; padding:3px 6px; border-radius:4px; font-size:11px; font-weight:700; margin-bottom:6px;">⚠️ Flagged for Review</div>` 
              : `<div style="background:#dcfce7; color:#15803d; padding:2px 6px; border-radius:4px; font-size:11px; font-weight:700; display:inline-block; margin-bottom:6px;">✅ Verified Lifesaver</div>`;

            const popup = `
              <div style="min-width:200px; font-family:inherit;">
                ${flagNotice}
                <h4 style="font-size:14px; margin:2px 0 4px; font-weight:800;">Donor: ${d.name}</h4>
                <div style="font-size:13px; font-weight:800; color:var(--primary); margin-bottom:4px;">Blood: ${d.blood_group}</div>
                <div style="font-size:12px; color:var(--muted); margin-bottom:8px;">📍 ${d.locality}, ${d.city}</div>
                <div style="display:flex; gap:6px;">
                  <a href="tel:${d.phone}" class="btn btn-primary btn-sm" style="flex:1; text-align:center;">📞 Contact</a>
                  <button onclick="openReportModal('donor', ${d.id}, '${d.name}')" class="btn btn-report">🚨 Report</button>
                </div>
              </div>
            `;
            marker.bindPopup(popup);
            this.donorsLayer.addLayer(marker);
          }
        });
      }
    } catch (e) {
      console.warn('Map donors loading issue:', e);
    }
  },

  async plotRequests() {
    try {
      const res = await fetch('/api/requests');
      const data = await res.json();
      if (data.success && data.requests) {
        this.requestsLayer.clearLayers();
        data.requests.forEach(r => {
          if (r.latitude && r.longitude) {
            const icon = L.divIcon({
              className: 'custom-map-icon',
              html: `<div class="custom-marker marker-request" title="Urgent: ${r.patient_name} (${r.blood_group})">🚨</div>`,
              iconSize: [32, 32],
              iconAnchor: [16, 16]
            });

            const marker = L.marker([r.latitude, r.longitude], { icon });
            const popup = `
              <div style="min-width:210px; font-family:inherit;">
                <div style="background:#fee2e2; color:#dc2626; padding:3px 8px; border-radius:4px; font-size:11px; font-weight:800; display:inline-block; margin-bottom:6px;">
                  🚨 ${r.urgency || 'Critical'} Blood Request
                </div>
                <h4 style="font-size:15px; margin:2px 0 4px; font-weight:800;">Patient: ${r.patient_name}</h4>
                <div style="font-size:13px; font-weight:800; color:var(--primary);">Need: ${r.units_needed} Units of ${r.blood_group} (${r.component})</div>
                <div style="font-size:12px; color:var(--muted); margin:4px 0 8px;">🏥 ${r.hospital_name}, ${r.locality}, ${r.city}</div>
                <div style="display:flex; gap:6px;">
                  <a href="tel:${r.contact_phone}" class="btn btn-emergency btn-sm" style="flex:1; text-align:center;">📞 Call Attendant</a>
                  <button onclick="openReportModal('request', ${r.id}, '${r.patient_name}')" class="btn btn-report">🚨 Report</button>
                </div>
              </div>
            `;
            marker.bindPopup(popup);
            this.requestsLayer.addLayer(marker);
          }
        });
      }
    } catch (e) {
      console.warn('Map requests loading issue:', e);
    }
  },

  async plotCamps() {
    try {
      const res = await fetch('/api/camps');
      const data = await res.json();
      if (data.success && data.camps) {
        this.campsLayer.clearLayers();
        data.camps.forEach(c => {
          if (c.latitude && c.longitude) {
            const icon = L.divIcon({
              className: 'custom-map-icon',
              html: `<div class="custom-marker marker-camp" style="background:#10b981; border-color:#059669; font-size:16px;" title="Camp: ${c.title}">⛺</div>`,
              iconSize: [32, 32],
              iconAnchor: [16, 16]
            });

            const marker = L.marker([c.latitude, c.longitude], { icon });
            const popup = `
              <div style="min-width:220px; font-family:inherit;">
                <div style="background:#dcfce7; color:#15803d; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:800; display:inline-block; margin-bottom:6px;">
                  ⛺ Blood Donation Camp
                </div>
                <h4 style="font-size:14px; margin:2px 0 4px; font-weight:800;">${c.title}</h4>
                <div style="font-size:12px; color:var(--muted); margin-bottom:4px;">🏢 ${c.organizer}</div>
                <div style="font-size:12px; font-weight:700; color:var(--primary); margin-bottom:4px;">📅 ${c.camp_date} (${c.start_time} - ${c.end_time})</div>
                <div style="font-size:12px; color:var(--slate); margin-bottom:8px;">📍 ${c.venue}, ${c.city}</div>
                <div style="display:flex; gap:6px;">
                  <button onclick="openCampRegisterModal(${c.id}, '${c.title.replace(/'/g, "\\'")}')" class="btn btn-primary btn-sm" style="flex:1;">🙋 Pre-Register</button>
                  <a href="tel:${c.contact_phone}" class="btn btn-outline btn-sm">📞 Call</a>
                </div>
              </div>
            `;
            marker.bindPopup(popup);
            this.campsLayer.addLayer(marker);
          }
        });
      }
    } catch (e) {
      console.warn('Map camps loading issue:', e);
    }
  },

  toggleLayer(layerName, btnEl) {
    if (!this.map) return;
    btnEl.classList.toggle('active');
    const isActive = btnEl.classList.contains('active');

    if (layerName === 'centers') {
      isActive ? this.map.addLayer(this.centersLayer) : this.map.removeLayer(this.centersLayer);
    } else if (layerName === 'donors') {
      isActive ? this.map.addLayer(this.donorsLayer) : this.map.removeLayer(this.donorsLayer);
    } else if (layerName === 'requests') {
      isActive ? this.map.addLayer(this.requestsLayer) : this.map.removeLayer(this.requestsLayer);
    } else if (layerName === 'camps') {
      isActive ? this.map.addLayer(this.campsLayer) : this.map.removeLayer(this.campsLayer);
    }
  },

  flyToCity(cityName) {
    document.querySelectorAll('.city-chip').forEach(c => c.classList.remove('active'));
    if (event && event.target) event.target.classList.add('active');

    if (!this.map) return;
    const target = this.jharkhandCities[cityName.toLowerCase()] || this.jharkhandCities['all'];
    this.map.flyTo([target.lat, target.lng], target.zoom, { duration: 1.4 });
    showToast(`Viewing locations in ${target.name}`, 'info');
  },

  detectGPS() {
    const badge = document.getElementById('gpsStatusBadge');
    const btn = document.getElementById('btnDetectGPS');

    if (!('geolocation' in navigator)) {
      showToast('Geolocation is not supported by your browser.', 'error');
      return;
    }

    if (btn) btn.disabled = true;
    if (badge) badge.textContent = 'Acquiring GPS fix...';
    showToast('Locating your position in Jharkhand...', 'info');

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        if (btn) btn.disabled = false;
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        this.userCoords = { lat, lng };

        if (this.map) {
          this.map.flyTo([lat, lng], 13, { duration: 1.5 });

          if (this.userMarker) {
            this.userLayer.removeLayer(this.userMarker);
          }

          const userIcon = L.divIcon({
            className: 'custom-map-icon',
            html: `<div class="custom-marker marker-user">📍</div>`,
            iconSize: [34, 34],
            iconAnchor: [17, 17]
          });

          this.userMarker = L.marker([lat, lng], { icon: userIcon })
            .bindPopup(`<b>You are here!</b><br>Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}`)
            .openPopup();
          this.userLayer.addLayer(this.userMarker);
        }

        // Reverse Geocoding with OpenStreetMap
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`);
          if (res.ok) {
            const data = await res.json();
            const addr = data.address || {};
            const city = addr.city || addr.town || addr.county || 'Ranchi';
            const locality = addr.suburb || addr.neighbourhood || addr.road || '';
            this.userCoords.city = city;
            this.userCoords.locality = locality;

            if (badge) badge.textContent = `📍 Near ${locality ? locality + ', ' : ''}${city}`;
            showToast(`Location detected: ${city} (${locality})`, 'success');

            const searchCity = document.getElementById('searchCity');
            if (searchCity && !searchCity.value) searchCity.value = city;
          }
        } catch (e) {
          if (badge) badge.textContent = `📍 GPS Active (${lat.toFixed(2)}, ${lng.toFixed(2)})`;
        }

        // Re-plot centers to show distance
        this.plotCenters();
      },
      (err) => {
        if (btn) btn.disabled = false;
        if (badge) badge.textContent = 'GPS Unavailable / Denied';
        showToast('Could not acquire GPS position. You can select your city manually.', 'error');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  },

  calcDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth radius in KM
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }
};


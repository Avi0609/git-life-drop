/**
 * LIFEDROP - MAIN APPLICATION LOGIC (js/app.js)
 * Modern Healthcare Controller, Anti-Fraud Security Layer & Clinical Utilities
 */

document.addEventListener('DOMContentLoaded', async () => {
  const yearEl = document.getElementById('currentYear');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  initTheme();
  initLanguage();

  await loadDashboardStats();
  if (typeof MapEngine !== 'undefined') {
    await MapEngine.init();
  }
  await loadEmergencyRequests();
  await loadCamps();
});

/* =========================================================
   1. LIVE DASHBOARD METRICS & STOCK MATRIX
   ========================================================= */
async function loadDashboardStats() {
  try {
    const res = await fetch('/api/stats');
    const data = await res.json();

    if (data.success && data.stats) {
      animateValue('kpiUnits', data.stats.totalUnitsAvailable || 0);
      animateValue('kpiDonors', data.stats.activeDonors || 0);
      animateValue('kpiCenters', data.stats.bloodCenters || 0);
      animateValue('kpiRequests', data.stats.openEmergencyRequests || 0);

      renderStockMatrix(data.stats.inventoryByGroup || []);
    }
  } catch (err) {
    console.warn('Dashboard stats load issue:', err);
  }
}

function animateValue(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  let current = 0;
  const duration = 1000;
  const step = Math.max(1, Math.floor(target / (duration / 30)));
  const timer = setInterval(() => {
    current += step;
    if (current >= target) {
      el.textContent = target;
      clearInterval(timer);
    } else {
      el.textContent = current;
    }
  }, 30);
}

function renderStockMatrix(invList) {
  const groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const grid = document.getElementById('inventoryGrid');
  if (!grid) return;

  const countMap = {};
  invList.forEach(item => {
    countMap[item.blood_group] = item.units;
  });

  grid.innerHTML = groups.map(grp => {
    const units = countMap[grp] || 0;
    let badgeClass = 'status-optimal';
    let badgeText = 'Normal Stock';

    if (units === 0) {
      badgeClass = 'status-low';
      badgeText = 'Depleted';
    } else if (units < 12) {
      badgeClass = 'status-low';
      badgeText = 'Critical Low';
    } else if (units < 25) {
      badgeClass = 'status-moderate';
      badgeText = 'Moderate';
    }

    return `
      <div class="blood-unit-box" onclick="quickFilterGroup('${grp}')" title="Click to view ${grp} availability in Jharkhand">
        <div class="group-badge">${grp}</div>
        <div class="unit-count">${units} Units</div>
        <span class="stock-status ${badgeClass}">${badgeText}</span>
      </div>
    `;
  }).join('');
}

function quickFilterGroup(group) {
  const bgSelect = document.getElementById('searchBloodGroup');
  if (bgSelect) bgSelect.value = group;

  const cityInput = document.getElementById('searchCity');
  if (cityInput && !cityInput.value) cityInput.value = 'Ranchi';

  const searchSec = document.getElementById('find-blood');
  if (searchSec) searchSec.scrollIntoView({ behavior: 'smooth' });

  searchBloodAvailability();
}

/* =========================================================
   2. BLOOD SEARCH & DIRECT COMPATIBILITY ENGINE
   ========================================================= */
async function searchBloodAvailability(e) {
  if (e && e.preventDefault) e.preventDefault();

  const cityEl = document.getElementById('searchCity');
  const city = (cityEl && cityEl.value && cityEl.value.trim()) ? cityEl.value.trim() : 'Ranchi';

  const localityEl = document.getElementById('searchLocality');
  const locality = localityEl ? localityEl.value.trim() : '';

  const bgEl = document.getElementById('searchBloodGroup');
  const bloodGroup = (bgEl && bgEl.value && bgEl.value.trim()) ? bgEl.value.trim() : 'O+';

  const compSelect = document.getElementById('searchComponent');
  const component = compSelect ? compSelect.value : 'Red cells';

  const compEl = document.getElementById('searchCompatible') || document.getElementById('checkCompatibility');
  const includeCompatible = compEl ? compEl.checked : true;

  const container = document.getElementById('searchResultsContainer');
  const grid = document.getElementById('searchResultsGrid') || document.getElementById('resultsGrid');
  const countPill = document.getElementById('resultsCountPill');
  const summary = document.getElementById('searchResultsSummary') || document.getElementById('searchQuerySummary');

  if (container) container.style.display = 'block';

  if (!grid) return;
  grid.innerHTML = '<div style="grid-column:1/-1; padding:40px; text-align:center; color:var(--muted);">🔍 Searching Jharkhand hospitals, blood banks and voluntary donors...</div>';

  try {
    const params = new URLSearchParams({
      city: city,
      locality: locality,
      bloodGroup: bloodGroup,
      component: component,
      includeCompatible: includeCompatible ? 'true' : 'false'
    });

    const res = await fetch(`/api/search?${params.toString()}`);
    const data = await res.json();

    if (!data.success) throw new Error(data.error || 'Search error');

    const centers = data.isFallback ? (data.nearbyCenters || []) : (data.centers || []);
    const donors = data.donors || [];
    const totalMatches = centers.length + donors.length;

    if (countPill) countPill.textContent = `${totalMatches} Available Matches`;

    if (summary) {
      if (data.isFallback) {
        summary.innerHTML = `⚠️ Direct local stock in <strong>${city}</strong> depleted. Showing <em>Nearest Regional Blood Centers & Donors</em>:`;
      } else {
        summary.innerHTML = `Blood Availability in <strong>${city}</strong> for <span style="color:var(--primary)">${bloodGroup}</span>:`;
      }
    }

    if (centers.length === 0 && donors.length === 0) {
      grid.innerHTML = `
        <div style="grid-column:1/-1; padding:36px; text-align:center; background:var(--bg); border-radius:var(--radius-md);">
          <h4 style="font-size:18px; margin-bottom:8px;">No stock currently found for ${bloodGroup} in ${city}</h4>
          <p style="color:var(--muted); font-size:14px; margin-bottom:16px;">
            We could not find active blood stock for ${bloodGroup} in this locality right now.
          </p>
          <button class="btn btn-emergency btn-sm" onclick="openRequestModal()">
            🚨 Post Immediate Emergency Request for ${bloodGroup}
          </button>
        </div>
      `;
      return;
    }

    let html = '';

    // Render Certified Centers
    centers.forEach(c => {
      let distStr = '';
      if (MapEngine.userCoords && c.latitude && c.longitude) {
        const km = MapEngine.calcDistance(MapEngine.userCoords.lat, MapEngine.userCoords.lng, c.latitude, c.longitude);
        distStr = `• 🧭 ~${km.toFixed(1)} km away`;
      }

      html += `
        <div class="result-card">
          <div>
            <div class="result-card-top">
              <span class="badge-verified">🏥 Certified Blood Bank</span>
              <span style="font-size:12px; font-weight:700; color:var(--emerald);">● Verified Active</span>
            </div>
            <h4 class="result-title">${c.center_name}</h4>
            <div class="result-meta">
              <span>📍 ${c.locality ? c.locality + ', ' : ''}${c.address}, ${c.city} ${distStr}</span>
              <span>🕒 Hours: ${c.operating_hours || '24/7 Emergency Service'}</span>
            </div>
            <div class="result-stock-pill">
              <span>🩸 Component: <strong>${c.component}</strong></span>
              <span>•</span>
              <span>Units in Stock: <strong style="color:var(--primary); font-size:15px;">${c.units_available} Units</strong></span>
            </div>
          </div>
          <div class="result-actions" style="display:flex; flex-wrap:wrap; gap:6px;">
            <a href="tel:${c.phone}" class="btn btn-primary btn-sm" style="flex:1;">
              📞 Call ${c.phone}
            </a>
            <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(c.center_name + ' ' + c.address)}" target="_blank" class="btn btn-outline btn-sm">
              🧭 Directions
            </a>
          </div>
        </div>
      `;
    });

    // Render Voluntary Donors
    donors.forEach(d => {
      const isSuspicious = d.suspicious_reports_count > 0;
      const statusBadge = isSuspicious 
        ? `<span class="badge-suspicious-alert">⚠️ Flagged by Community</span>`
        : `<span class="badge-verified">❤️ Verified Voluntary Lifesaver</span>`;

      const safeDonorJson = JSON.stringify(d).replace(/'/g, "&apos;").replace(/"/g, "&quot;");

      html += `
        <div class="result-card" style="${isSuspicious ? 'border-color:#fca5a5;' : ''}">
          <div>
            <div class="result-card-top">
              ${statusBadge}
              <span style="font-size:12px; font-weight:700; color:var(--emerald);">● Ready to Donate</span>
            </div>
            <h4 class="result-title">${d.name}</h4>
            <div class="result-meta">
              <span>📍 Voluntary Donor in <strong>${d.locality || d.city}</strong>, ${d.city}</span>
              <span>🩸 Blood Group: <strong style="color:var(--primary); font-size:15px;">${d.blood_group}</strong></span>
            </div>
          </div>
          <div class="result-actions" style="display:flex; flex-wrap:wrap; gap:6px;">
            <a href="tel:${d.phone}" class="btn btn-primary btn-sm" style="flex:1;">
              📞 Call
            </a>
            <button onclick="openWhatsAppChat('${d.phone}', '${d.name.replace(/'/g, "\\'")}', '${d.blood_group}', '${d.city}')" class="btn btn-whatsapp btn-sm">
              💬 WhatsApp
            </button>
            <button onclick='openDonorCardModal(${safeDonorJson})' class="btn btn-outline btn-sm">
              🪪 ID Card
            </button>
            <button onclick="openReportModal('donor', ${d.id}, '${d.name.replace(/'/g, "\\'")}')" class="btn btn-report btn-sm">
              🚨 Report
            </button>
          </div>
        </div>
      `;
    });

    grid.innerHTML = html;
    showToast(`Search completed: ${totalMatches} available options found`, 'success');

    if (container) {
      container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  } catch (err) {
    console.error('Search error:', err);
    grid.innerHTML = `<div style="grid-column:1/-1; padding:30px; text-align:center; color:var(--primary);">Error executing search. Please try again.</div>`;
    showToast('Search query failed: ' + err.message, 'error');
  }
}

/* =========================================================
   3. EMERGENCY REQUESTS FEED & SUBMISSION
   ========================================================= */
async function loadEmergencyRequests() {
  const container = document.getElementById('urgentCardsContainer');
  if (!container) return;

  try {
    const res = await fetch('/api/requests');
    const data = await res.json();

    if (data.success && data.requests) {
      if (data.requests.length === 0) {
        container.innerHTML = `
          <div style="grid-column:1/-1; text-align:center; padding:30px; background:#fff; border-radius:var(--radius-md);">
            <p style="color:var(--muted)">No open critical requests at this moment in Jharkhand.</p>
          </div>
        `;
        return;
      }

      container.innerHTML = data.requests.map(req => {
        const urgencyClass = (req.urgency || '').toLowerCase();
        const pillClass = urgencyClass === 'critical' ? 'pill-critical' : (urgencyClass === 'high' ? 'pill-high' : 'pill-normal');

        return `
          <article class="urgent-card ${urgencyClass}">
            <div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <span class="urgency-pill ${pillClass}">⚠️ ${req.urgency || 'Normal'} Priority</span>
                <strong style="color:var(--primary); font-size:18px;">${req.blood_group}</strong>
              </div>
              <h4 class="urgent-patient">Patient: ${req.patient_name}</h4>
              <div class="urgent-hospital">🏥 ${req.hospital_name}, ${req.locality ? req.locality + ', ' : ''}${req.city}</div>
              <div class="urgent-detail-row">
                <span>Component: <strong>${req.component}</strong></span>
                <span>Required: <strong>${req.units_needed} Units</strong></span>
              </div>
            </div>
            <div style="display:flex; flex-wrap:wrap; gap:8px;">
              <a href="tel:${req.contact_phone}" class="btn btn-emergency btn-sm" style="flex:1; text-align:center;">
                📞 Call: ${req.contact_phone}
              </a>
              <button onclick="shareEmergencyOnWhatsApp('${req.patient_name.replace(/'/g, "\\'")}', '${req.blood_group}', ${req.units_needed}, '${req.hospital_name.replace(/'/g, "\\'")}', '${req.city}', '${req.contact_phone}')" class="btn btn-whatsapp btn-sm" title="Broadcast alert to WhatsApp groups">
                📲 Share Alert
              </button>
              <button onclick="openReportModal('request', ${req.id}, '${req.patient_name.replace(/'/g, "\\'")}')" class="btn btn-report btn-sm" title="Report fake request">
                🚨 Report
              </button>
            </div>
          </article>
        `;
      }).join('');
    }
  } catch (err) {
    console.warn('Emergency requests load error:', err);
  }
}

async function submitEmergencyBloodRequest(e) {
  e.preventDefault();

  const payload = {
    patientName: document.getElementById('reqPatient').value,
    bloodGroup: document.getElementById('reqBloodGroup').value,
    component: document.getElementById('reqComponent').value,
    unitsNeeded: document.getElementById('reqUnits').value,
    hospitalName: document.getElementById('reqHospital').value,
    city: document.getElementById('reqCity').value,
    locality: document.getElementById('reqLocality').value,
    contactName: document.getElementById('reqContactName').value,
    contactPhone: document.getElementById('reqContactPhone').value,
    urgency: document.getElementById('reqUrgency').value,
    latitude: MapEngine.userCoords ? MapEngine.userCoords.lat : null,
    longitude: MapEngine.userCoords ? MapEngine.userCoords.lng : null
  };

  try {
    const res = await fetch('/api/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (data.success) {
      showToast('🚨 Emergency request posted to Jharkhand Blood Grid!', 'success');
      closeRequestModal();
      document.getElementById('emergencyRequestForm').reset();
      await loadEmergencyRequests();
      await loadDashboardStats();
      if (typeof MapEngine !== 'undefined') MapEngine.plotRequests();
    } else {
      showToast(data.error || 'Failed to submit request', 'error');
    }
  } catch (err) {
    showToast('Network error posting emergency request', 'error');
  }
}

/* =========================================================
   4. VOLUNTARY DONOR REGISTRATION
   ========================================================= */
async function submitDonorRegistration(e) {
  e.preventDefault();

  const btn = document.getElementById('btnSubmitDonor');
  btn.disabled = true;
  btn.textContent = 'Registering lifesaver...';

  const payload = {
    name: document.getElementById('regName').value,
    phone: document.getElementById('regPhone').value,
    email: document.getElementById('regEmail').value,
    bloodGroup: document.getElementById('regBloodGroup').value,
    city: document.getElementById('regCity').value,
    locality: document.getElementById('regLocality').value,
    address: document.getElementById('regAddress').value,
    age: document.getElementById('regAge').value,
    gender: document.getElementById('regGender').value,
    latitude: MapEngine.userCoords ? MapEngine.userCoords.lat : null,
    longitude: MapEngine.userCoords ? MapEngine.userCoords.lng : null
  };

  try {
    const res = await fetch('/api/donors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (data.success) {
      showToast(`❤️ Welcome ${payload.name}! You are registered as Verified Donor #${data.donorId}`, 'success');
      document.getElementById('donorRegisterForm').reset();
      await loadDashboardStats();
      if (typeof MapEngine !== 'undefined') MapEngine.plotDonors();

      // Automatically generate & display Digital Donor ID Card
      openDonorCardModal({
        id: data.donorId,
        name: payload.name,
        phone: payload.phone,
        blood_group: payload.bloodGroup,
        city: payload.city,
        locality: payload.locality,
        age: payload.age,
        gender: payload.gender
      });
    } else {
      showToast(data.error || 'Registration failed', 'error');
    }
  } catch (err) {
    showToast('Network error connecting to server', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '❤️ Register as Voluntary Lifesaver';
  }
}

function autoFillDonorGPS() {
  if (MapEngine.userCoords && MapEngine.userCoords.city) {
    document.getElementById('regCity').value = MapEngine.userCoords.city;
    if (MapEngine.userCoords.locality) {
      document.getElementById('regLocality').value = MapEngine.userCoords.locality;
    }
    showToast(`Location auto-filled: ${MapEngine.userCoords.city}`, 'success');
  } else {
    MapEngine.detectGPS();
    setTimeout(() => {
      if (MapEngine.userCoords && MapEngine.userCoords.city) {
        document.getElementById('regCity').value = MapEngine.userCoords.city;
        if (MapEngine.userCoords.locality) {
          document.getElementById('regLocality').value = MapEngine.userCoords.locality;
        }
      }
    }, 2000);
  }
}

/* =========================================================
   5. SUSPICIOUS PROFILE REPORTING (ANTI-FRAUD LAYER)
   ========================================================= */
function openReportModal(targetType, targetId, reportedName) {
  document.getElementById('repTargetType').value = targetType;
  document.getElementById('repTargetId').value = targetId;
  document.getElementById('repTargetName').value = reportedName;
  document.getElementById('repTargetDisplay').textContent = `${targetType.toUpperCase()}: ${reportedName} (#${targetId})`;
  document.getElementById('reportModal').classList.add('active');
}

function closeReportModal() {
  document.getElementById('reportModal').classList.remove('active');
}

async function submitSuspiciousReport(e) {
  e.preventDefault();

  const payload = {
    targetType: document.getElementById('repTargetType').value,
    targetId: document.getElementById('repTargetId').value,
    reportedName: document.getElementById('repTargetName').value,
    reason: document.getElementById('repReason').value,
    details: document.getElementById('repDetails').value,
    reporterContact: document.getElementById('repContact').value
  };

  try {
    const res = await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (data.success) {
      showToast('🛡️ Report received. Our safety team will investigate and restrict this profile if found fraudulent.', 'success');
      closeReportModal();
      document.getElementById('reportForm').reset();
    } else {
      showToast(data.error || 'Failed to submit report', 'error');
    }
  } catch (err) {
    showToast('Network error submitting report', 'error');
  }
}

/* =========================================================
   6. MODAL & TOAST HELPERS
   ========================================================= */
function openRequestModal() {
  document.getElementById('requestModal').classList.add('active');
}

function closeRequestModal() {
  document.getElementById('requestModal').classList.remove('active');
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = 'ℹ️';
  if (type === 'success') icon = '✅';
  if (type === 'error') icon = '⚠️';

  toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}

function toggleMobileMenu() {
  const nav = document.querySelector('.nav-links');
  if (!nav) return;
  if (nav.style.display === 'flex') {
    nav.style.display = 'none';
  } else {
    nav.style.display = 'flex';
    nav.style.flexDirection = 'column';
    nav.style.position = 'absolute';
    nav.style.top = '74px';
    nav.style.left = '0';
    nav.style.right = '0';
    nav.style.background = '#ffffff';
    nav.style.padding = '20px';
    nav.style.boxShadow = 'var(--shadow-md)';
  }
}

/* =========================================================
   7. 🌙 THEME CONTROLLER (NIGHT EMERGENCY / DAY MODE)
   ========================================================= */
function initTheme() {
  const saved = localStorage.getItem('lifedrop_theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved);
  updateThemeButtonUI(saved);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('lifedrop_theme', next);
  updateThemeButtonUI(next);
  showToast(next === 'dark' ? '🌙 Night Emergency Mode activated' : '☀️ Day Mode activated', 'info');
}

function updateThemeButtonUI(theme) {
  const btn = document.getElementById('themeToggleBtn');
  if (btn) {
    btn.innerHTML = theme === 'dark' ? '☀️ Day' : '🌙 Dark';
  }
}

/* =========================================================
   8. 🌐 LANGUAGE TRANSLATION ENGINE (ENGLISH / हिन्दी)
   ========================================================= */
const I18N_DICT = {
  en: {
    heroTitle: 'Every Drop Saves A Life.<br><span>Right Here in Jharkhand.</span>',
    heroDesc: 'LifeDrop connects patients directly with certified blood banks and verified voluntary lifesavers across <strong>Ranchi</strong>, <strong>Bokaro</strong>, <strong>Jamshedpur</strong>, <strong>Ramgarh</strong>, <strong>Deoghar</strong>, and <strong>Hazaribagh</strong>.',
    findBloodBtn: '🔍 Find Blood in Jharkhand',
    registerDonorBtn: '❤️ Register as Donor',
    calcHeading: 'Medical Eligibility & Next Donation Calculator',
    calcSub: 'Check your eligibility criteria and find out exactly when you can donate next',
    campsHeading: 'Upcoming Blood Donation Camps in Jharkhand',
    campsSub: 'Join mobile drives and voluntary blood donation camps near you',
    urgentHeading: 'Critical Hospital Blood Board',
    urgentSub: 'Live patient requests across RIMS, BGH, TMH, Sadar Hospitals, and AIIMS Deoghar',
    mapHeading: 'Interactive Blood Network Map',
    mapSub: 'Real-time GPS visualization of Blood Banks, Verified Donors & Emergency Requests'
  },
  hi: {
    heroTitle: 'रक्त का हर कतरा बचाता है ज़िंदगी।<br><span>यहीं झारखण्ड में।</span>',
    heroDesc: 'LifeDrop मरीजों को <strong>राँची</strong>, <strong>बोकारो</strong>, <strong>जमशेदपुर</strong>, <strong>रामगढ़</strong>, <strong>देवघर</strong>, और <strong>हज़ारीबाग़</strong> के प्रमाणित ब्लड बैंकों और सत्यापित रक्तदाताओं से सीधे जोड़ता है।',
    findBloodBtn: '🔍 झारखण्ड में रक्त खोजें',
    registerDonorBtn: '❤️ रक्तदान के लिए जुड़ें',
    calcHeading: 'रक्तदान पात्रता एवं आगामी तिथि कैलकुलेटर',
    calcSub: 'अपनी चिकित्सीय पात्रता जाँचें और जानें कि आप अगली बार कब रक्तदान कर सकते हैं',
    campsHeading: 'झारखण्ड में आगामी रक्तदान शिविर (कैंप)',
    campsSub: 'अपने निकटतम स्वैच्छिक रक्तदान शिविरों और मोबाइल वैन से जुड़ें',
    urgentHeading: 'अस्पतालों का लाइव इमरजेंसी ब्लड बोर्ड',
    urgentSub: 'रिम्स (RIMS), बीजीएच (BGH), टीएमएच (TMH) एवं एम्स देवघर में भर्ती मरीजों की आपातकालीन आवश्यकताएं',
    mapHeading: 'इंटरैक्टिव ब्लड नेटवर्क नक्शा',
    mapSub: 'ब्लड बैंक, सत्यापित रक्तदाता एवं इमरजेंसी मरीजों की लाइव जीपीएस मैपिंग'
  }
};

let currentLang = 'en';

function initLanguage() {
  currentLang = localStorage.getItem('lifedrop_lang') || 'en';
  applyLanguage(currentLang);
}

function toggleLanguage() {
  currentLang = currentLang === 'en' ? 'hi' : 'en';
  localStorage.setItem('lifedrop_lang', currentLang);
  applyLanguage(currentLang);
  showToast(currentLang === 'hi' ? '🌐 भाषा: हिन्दी सेट की गई' : '🌐 Language: English set', 'info');
}

function applyLanguage(lang) {
  const dict = I18N_DICT[lang] || I18N_DICT['en'];
  const langBtn = document.getElementById('langToggleBtn');
  if (langBtn) {
    langBtn.innerHTML = lang === 'hi' ? '🌐 English' : '🌐 हिन्दी';
  }

  const heroTitle = document.getElementById('heroTitleText');
  if (heroTitle) heroTitle.innerHTML = dict.heroTitle;

  const heroDesc = document.getElementById('heroDescText');
  if (heroDesc) heroDesc.innerHTML = dict.heroDesc;

  const calcH2 = document.getElementById('calcSectionTitle');
  if (calcH2) calcH2.textContent = dict.calcHeading;
  const calcP = document.getElementById('calcSectionSub');
  if (calcP) calcP.textContent = dict.calcSub;

  const campsH2 = document.getElementById('campsSectionTitle');
  if (campsH2) campsH2.textContent = dict.campsHeading;
  const campsP = document.getElementById('campsSectionSub');
  if (campsP) campsP.textContent = dict.campsSub;

  const urgentH2 = document.getElementById('urgentSectionTitle');
  if (urgentH2) urgentH2.textContent = dict.urgentHeading;
  const urgentP = document.getElementById('urgentSectionSub');
  if (urgentP) urgentP.textContent = dict.urgentSub;
}

/* =========================================================
   9. 📲 WHATSAPP EMERGENCY BROADCAST & DIRECT CHAT
   ========================================================= */
function shareEmergencyOnWhatsApp(patientName, bloodGroup, units, hospital, city, phone) {
  const text = `🚨 *URGENT BLOOD REQUIRED IN JHARKHAND!*\n\n` +
    `👤 *Patient:* ${patientName}\n` +
    `🩸 *Blood Group Needed:* ${bloodGroup} (${units} Units)\n` +
    `🏥 *Hospital:* ${hospital}, ${city}\n` +
    `📞 *Contact Attendant:* ${phone}\n\n` +
    `⚠️ Voluntary Blood Donation is 100% FREE. Never pay brokers.\n` +
    `🔗 Verified on LifeDrop Network: ${window.location.origin}`;
  
  const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

function openWhatsAppChat(phone, name, bloodGroup, city) {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const finalPhone = cleanPhone.startsWith('91') ? cleanPhone : '91' + cleanPhone;
  const text = `Namaste ${name} ji, I found your voluntary donor contact on LifeDrop Jharkhand. We urgently need a ${bloodGroup} blood donor in ${city}. Are you available to donate?`;
  const url = `https://wa.me/${finalPhone}?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

function shareCampOnWhatsApp(title, date, venue, city, phone) {
  const text = `🏕️ *BLOOD DONATION DRIVE IN ${city.toUpperCase()}!*\n\n` +
    `🎯 *Camp:* ${title}\n` +
    `📅 *Date:* ${date}\n` +
    `📍 *Venue:* ${venue}\n` +
    `📞 *Inquiries:* ${phone}\n\n` +
    `Every voluntary drop saves a life! Join us or share with friends.\n` +
    `🔗 LifeDrop Jharkhand: ${window.location.origin}#camps`;
  const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

/* =========================================================
   10. 🪪 DIGITAL VOLUNTARY DONOR ID CARD & CERTIFICATE
   ========================================================= */
function openDonorCardModal(donor) {
  if (!donor) return;
  const modal = document.getElementById('donorCardModal');
  if (!modal) return;

  const cardId = `LD-JH-${String(donor.id || 1).padStart(5, '0')}`;
  document.getElementById('dcCardId').textContent = cardId;
  document.getElementById('dcDonorName').textContent = donor.name || 'Voluntary Lifesaver';
  document.getElementById('dcBloodGroup').textContent = donor.blood_group || donor.bloodGroup || 'O+';
  document.getElementById('dcLocation').textContent = `${donor.locality ? donor.locality + ', ' : ''}${donor.city || 'Jharkhand'}`;
  document.getElementById('dcPhone').textContent = donor.phone || 'Verified Voluntary Contact';
  document.getElementById('dcMemberSince').textContent = `Member since ${new Date().getFullYear()}`;

  modal.classList.add('active');
}

function closeDonorCardModal() {
  const modal = document.getElementById('donorCardModal');
  if (modal) modal.classList.remove('active');
}

function printDonorCard() {
  window.print();
}

/* =========================================================
   11. 📅 MEDICAL ELIGIBILITY & NEXT DONATION CALCULATOR
   ========================================================= */
function calculateEligibility(e) {
  if (e) e.preventDefault();

  const gender = document.querySelector('input[name="calcGender"]:checked')?.value || 'male';
  const lastDateVal = document.getElementById('calcLastDonationDate').value;
  const age = parseInt(document.getElementById('calcAge').value, 10);
  const weight = parseFloat(document.getElementById('calcWeight').value);
  const hadTattoo = document.getElementById('calcTattoo').checked;
  const hadAlcohol = document.getElementById('calcAlcohol').checked;

  const resultBox = document.getElementById('calcResultBox');
  if (!resultBox) return;

  // Checklist verification
  const issues = [];
  if (isNaN(age) || age < 18 || age > 65) issues.push('Age must be between 18 and 65 years.');
  if (isNaN(weight) || weight < 45) issues.push('Body weight must be at least 45 kg (50 kg recommended for whole blood).');
  if (hadTattoo) issues.push('Must wait at least 6 months after tattoo, piercing, or major surgery.');
  if (hadAlcohol) issues.push('Must not have consumed alcohol in the past 24 hours.');

  if (issues.length > 0) {
    resultBox.innerHTML = `
      <div class="calc-result-banner status-ineligible">
        <div style="font-size:24px; margin-bottom:6px;">⚠️ Not Eligible Today</div>
        <p style="font-size:14px; margin-bottom:8px;">Please review the following medical criteria before donating:</p>
        <ul style="text-align:left; font-size:13px; line-height:1.6; padding-left:20px;">
          ${issues.map(iss => `<li>${iss}</li>`).join('')}
        </ul>
      </div>
    `;
    return;
  }

  // Interval check: 90 days male, 120 days female
  const intervalDays = gender === 'female' ? 120 : 90;

  if (lastDateVal) {
    const lastDate = new Date(lastDateVal);
    const today = new Date();
    const diffTime = today - lastDate;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < intervalDays) {
      const daysRemaining = intervalDays - diffDays;
      const nextDate = new Date(lastDate.getTime() + intervalDays * 24 * 60 * 60 * 1000);
      const dateString = nextDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

      resultBox.innerHTML = `
        <div class="calc-result-banner status-waiting">
          <div class="countdown-number">${daysRemaining}</div>
          <div class="countdown-label">Days to Complete Donation Recovery Interval</div>
          <div style="font-size:15px; margin-top:8px;">
            Eligible to donate on: <strong>${dateString}</strong>
          </div>
          <p style="font-size:12px; color:var(--muted); margin-top:6px;">
            (${gender === 'female' ? '120-day interval for females' : '90-day interval for males'} per National Blood Transfusion Council guidelines).
          </p>
        </div>
      `;
      return;
    }
  }

  // Fully Eligible!
  resultBox.innerHTML = `
    <div class="calc-result-banner status-eligible">
      <div style="font-size:32px; margin-bottom:4px;">🎉</div>
      <div style="font-size:20px; font-weight:800; margin-bottom:4px;">You Are Fully Eligible to Donate Blood!</div>
      <p style="font-size:14px; margin-bottom:12px;">
        Your health parameters meet NBTC safety standards. Your single donation can save up to 3 lives in Jharkhand.
      </p>
      <div style="display:flex; justify-content:center; gap:10px;">
        <a href="#donate" class="btn btn-primary btn-sm">❤️ Register as Donor</a>
        <a href="#camps" class="btn btn-outline btn-sm">🏕️ Find Next Camp</a>
      </div>
    </div>
  `;
}

/* =========================================================
   12. 🏕️ BLOOD DONATION CAMPS & MOBILE DRIVES
   ========================================================= */
async function loadCamps(cityFilter = '') {
  const grid = document.getElementById('campsGridContainer');
  if (!grid) return;

  try {
    const url = cityFilter ? `/api/camps?city=${encodeURIComponent(cityFilter)}` : '/api/camps';
    const res = await fetch(url);
    const data = await res.json();

    if (data.success && data.camps) {
      if (data.camps.length === 0) {
        grid.innerHTML = `<div style="grid-column:1/-1; padding:30px; text-align:center; color:var(--muted);">No blood donation camps scheduled in this city right now. Check back soon!</div>`;
        return;
      }

      grid.innerHTML = data.camps.map(camp => {
        const percent = Math.min(100, Math.round(((camp.registered_donors_count || 0) / (camp.target_units || 100)) * 100));
        return `
          <div class="camp-card">
            <div>
              <div class="camp-date-badge">
                📅 ${camp.camp_date} (${camp.start_time} - ${camp.end_time})
              </div>
              <h3 class="camp-title">${camp.title}</h3>
              <div class="camp-organizer">🏢 Organized by: <strong>${camp.organizer}</strong></div>
              <div class="camp-venue">📍 <strong>Venue:</strong> ${camp.venue}, ${camp.city}</div>
              <div class="camp-progress-wrap">
                <div style="display:flex; justify-content:space-between; font-size:12px; font-weight:700;">
                  <span>Volunteers Registered: ${camp.registered_donors_count || 0}</span>
                  <span style="color:var(--primary);">Goal: ${camp.target_units} Units</span>
                </div>
                <div class="camp-progress-bar">
                  <div class="camp-progress-fill" style="width: ${percent}%;"></div>
                </div>
              </div>
            </div>
            <div class="camp-actions">
              <button onclick="openCampRegisterModal(${camp.id}, '${camp.title.replace(/'/g, "\\'")}')" class="btn btn-primary btn-sm" style="flex:1;">
                🙋 Pre-Register
              </button>
              <button onclick="shareCampOnWhatsApp('${camp.title.replace(/'/g, "\\'")}', '${camp.camp_date}', '${camp.venue.replace(/'/g, "\\'")}', '${camp.city}', '${camp.contact_phone}')" class="btn btn-whatsapp btn-sm" title="Share with WhatsApp groups">
                📲 Share
              </button>
            </div>
          </div>
        `;
      }).join('');
    }
  } catch (err) {
    console.warn('Error loading camps:', err);
  }
}

function openCampRegisterModal(campId, campTitle) {
  document.getElementById('campRegCampId').value = campId;
  document.getElementById('campRegCampTitleDisplay').textContent = campTitle;
  document.getElementById('campRegisterModal').classList.add('active');
}

function closeCampRegisterModal() {
  document.getElementById('campRegisterModal').classList.remove('active');
}

async function submitCampRegistration(e) {
  e.preventDefault();
  const campId = document.getElementById('campRegCampId').value;
  const payload = {
    donorName: document.getElementById('campRegName').value,
    phone: document.getElementById('campRegPhone').value,
    bloodGroup: document.getElementById('campRegBlood').value
  };

  try {
    const res = await fetch(`/api/camps/${campId}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      closeCampRegisterModal();
      document.getElementById('campRegisterForm').reset();
      await loadCamps();
    } else {
      showToast(data.error || 'Registration failed', 'error');
    }
  } catch (err) {
    showToast('Network error registering for camp', 'error');
  }
}

/* =========================================================
   13. 🏥 HOSPITAL ADMIN PORTAL & FRAUD MODERATION
   ========================================================= */
let adminAuthed = false;

function openAdminModal() {
  const modal = document.getElementById('adminModal');
  if (!modal) return;
  modal.classList.add('active');
  if (!adminAuthed) {
    document.getElementById('adminAuthSection').style.display = 'block';
    document.getElementById('adminPortalSection').style.display = 'none';
  } else {
    document.getElementById('adminAuthSection').style.display = 'none';
    document.getElementById('adminPortalSection').style.display = 'block';
    loadAdminCentersSelect();
    loadAdminReports();
  }
}

function closeAdminModal() {
  document.getElementById('adminModal').classList.remove('active');
}

function verifyAdminPasscode(e) {
  e.preventDefault();
  const entered = document.getElementById('adminPasscodeInput').value.trim();
  if (entered === '1234') {
    adminAuthed = true;
    document.getElementById('adminAuthSection').style.display = 'none';
    document.getElementById('adminPortalSection').style.display = 'block';
    showToast('Hospital Admin Console Unlocked', 'success');
    loadAdminCentersSelect();
    loadAdminReports();
  } else {
    showToast('Invalid Hospital Passcode. (Default is 1234)', 'error');
  }
}

function switchAdminTab(tabName) {
  document.querySelectorAll('.admin-tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`tabBtn_${tabName}`)?.classList.add('active');

  document.getElementById('adminTabStock').style.display = tabName === 'stock' ? 'block' : 'none';
  document.getElementById('adminTabFraud').style.display = tabName === 'fraud' ? 'block' : 'none';

  if (tabName === 'fraud') loadAdminReports();
}

async function loadAdminCentersSelect() {
  try {
    const res = await fetch('/api/centers');
    const data = await res.json();
    const select = document.getElementById('adminCenterSelect');
    if (select && data.success && data.centers) {
      select.innerHTML = data.centers.map(c => `
        <option value="${c.id}">${c.name} (${c.city})</option>
      `).join('');
      if (data.centers.length > 0) {
        loadAdminCenterStock(data.centers[0].id);
      }
    }
  } catch (e) {
    console.warn('Admin centers load error:', e);
  }
}

async function loadAdminCenterStock(centerId) {
  const tableBody = document.getElementById('adminStockTableBody');
  if (!tableBody) return;
  tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px;">Loading stock...</td></tr>';

  try {
    const res = await fetch(`/api/centers/${centerId}`);
    const data = await res.json();
    if (data.success && data.inventory) {
      if (data.inventory.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px;">No inventory records found for this center.</td></tr>';
        return;
      }
      tableBody.innerHTML = data.inventory.map(item => `
        <tr>
          <td><strong style="color:var(--primary); font-size:15px;">${item.blood_group}</strong></td>
          <td>${item.component}</td>
          <td>
            <input type="number" min="0" value="${item.units_available}" id="stockInput_${item.id}" class="stock-input"> Units
          </td>
          <td>
            <button onclick="saveAdminStockItem(${centerId}, '${item.blood_group}', '${item.component}', ${item.id})" class="btn btn-primary btn-sm">💾 Update</button>
          </td>
        </tr>
      `).join('');
    }
  } catch (e) {
    tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:red;">Failed to load inventory.</td></tr>';
  }
}

async function saveAdminStockItem(centerId, bloodGroup, component, itemId) {
  const input = document.getElementById(`stockInput_${itemId}`);
  if (!input) return;
  const newUnits = parseInt(input.value, 10);

  try {
    const res = await fetch(`/api/centers/${centerId}/inventory`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passcode: '1234', bloodGroup, component, units: newUnits })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      await loadDashboardStats();
    } else {
      showToast(data.error || 'Failed to update stock', 'error');
    }
  } catch (e) {
    showToast('Network error saving inventory', 'error');
  }
}

async function loadAdminReports() {
  const tableBody = document.getElementById('adminFraudTableBody');
  if (!tableBody) return;
  tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px;">Loading fraud reports...</td></tr>';

  try {
    const res = await fetch('/api/reports');
    const data = await res.json();
    if (data.success && data.reports) {
      if (data.reports.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px; color:var(--emerald);">✅ No pending suspicious reports. LifeDrop network clean!</td></tr>';
        return;
      }
      tableBody.innerHTML = data.reports.map(rep => {
        const isResolved = rep.status === 'Verified Fraud' || rep.status === 'Dismissed';
        return `
          <tr>
            <td>#${rep.id}</td>
            <td><strong>${rep.reported_name}</strong><br><small style="color:var(--muted);">${rep.target_type}</small></td>
            <td style="color:#b91c1c; font-weight:700;">${rep.reason}</td>
            <td style="font-size:12px; max-width:200px;">${rep.details || 'N/A'}</td>
            <td><span class="stock-status ${rep.status === 'Verified Fraud' ? 'status-low' : 'status-moderate'}">${rep.status}</span></td>
            <td>
              ${isResolved ? '<span style="color:var(--muted); font-size:12px;">Resolved</span>' : `
                <div style="display:flex; gap:6px;">
                  <button onclick="resolveFraudReport(${rep.id}, 'Verified Fraud', true)" class="btn btn-emergency btn-sm">🚫 Ban Profile</button>
                  <button onclick="resolveFraudReport(${rep.id}, 'Dismissed', false)" class="btn btn-outline btn-sm">Dismiss</button>
                </div>
              `}
            </td>
          </tr>
        `;
      }).join('');
    }
  } catch (e) {
    tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:red;">Failed to load reports.</td></tr>';
  }
}

async function resolveFraudReport(reportId, status, banTarget) {
  try {
    const res = await fetch(`/api/reports/${reportId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passcode: '1234', status, banTarget })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      loadAdminReports();
      await loadDashboardStats();
      if (typeof MapEngine !== 'undefined') MapEngine.loadAllMapData();
    } else {
      showToast(data.error || 'Failed to update report status', 'error');
    }
  } catch (e) {
    showToast('Network error updating report', 'error');
  }
}

// Function aliases for HTML event bindings
const executeBloodSearch = searchBloodAvailability;
const handleDonorRegistration = submitDonorRegistration;
const handleEmergencyRequest = submitEmergencyBloodRequest;
const handleSuspiciousReport = submitSuspiciousReport;

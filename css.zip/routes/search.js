const express = require('express');
const router = express.Router();
const db = require('../db');

// Blood Compatibility Map for Red Blood Cells
const COMPATIBILITY_MAP = {
  'O-': ['O-'],
  'O+': ['O+', 'O-'],
  'A-': ['A-', 'O-'],
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-']
};

// City & Locality Alias Map for Jharkhand & Major Regions
const JHARKHAND_CLUSTERS = {
  // Ranchi & Localities
  'ranchi': ['Ranchi', 'Bariatu', 'Lalpur', 'Morabadi', 'Firayalal', 'Kantatoli', 'Khatal', 'Doranda', 'Harmu', 'Hinoo', 'Dhurwa'],
  'bariatu': ['Bariatu', 'Ranchi'],
  'lalpur': ['Lalpur', 'Ranchi'],
  'morabadi': ['Morabadi', 'Ranchi'],
  'firayalal': ['Firayalal', 'Ranchi'],
  'kantatoli': ['Kantatoli', 'Ranchi'],
  'khatal': ['Khatal', 'Ranchi'],
  'doranda': ['Doranda', 'Ranchi'],

  // Bokaro (Sectors 1 to 12 & Chas)
  'bokaro': ['Bokaro', 'Sector 1', 'Sector 2', 'Sector 3', 'Sector 4', 'Sector 5', 'Sector 6', 'Sector 7', 'Sector 8', 'Sector 9', 'Sector 10', 'Sector 11', 'Sector 12', 'Chas', 'BGH'],
  'bokaro steel city': ['Bokaro', 'Sector 4', 'Sector 1', 'Sector 6', 'Sector 9', 'Sector 12', 'Chas'],
  'chas': ['Chas', 'Bokaro'],
  'sector 4': ['Sector 4', 'Bokaro'],
  'sector 1': ['Sector 1', 'Bokaro'],
  'sector 6': ['Sector 6', 'Bokaro'],
  'sector 9': ['Sector 9', 'Bokaro'],
  'sector 12': ['Sector 12', 'Bokaro'],

  // Jamshedpur / Tatanagar
  'jamshedpur': ['Jamshedpur', 'Bistupur', 'Sakchi', 'Kadma', 'Sonari', 'Telco', 'Tatanagar'],
  'tata': ['Jamshedpur', 'Bistupur', 'Sakchi', 'Telco'],
  'tatanagar': ['Jamshedpur', 'Bistupur', 'Sakchi', 'Telco'],
  'bistupur': ['Bistupur', 'Jamshedpur'],
  'sakchi': ['Sakchi', 'Jamshedpur'],
  'telco': ['Telco', 'Jamshedpur'],

  // Ramgarh
  'ramgarh': ['Ramgarh', 'Ramgarh Cantt', 'Subhash Chowk', 'Gola Road'],
  'ramgarh cantt': ['Ramgarh', 'Ramgarh Cantt'],

  // Deoghar
  'deoghar': ['Deoghar', 'Castairs Town', 'AIIMS Campus', 'Tower Chowk'],
  'aiims deoghar': ['Deoghar', 'AIIMS Campus'],

  // Hazaribagh
  'hazaribagh': ['Hazaribagh', 'Matwari', 'Korrah'],
  'hazaribag': ['Hazaribagh', 'Matwari', 'Korrah']
};

function resolveSearchTerms(inputLocation) {
  if (!inputLocation) return [];
  const clean = inputLocation.trim().toLowerCase();

  if (JHARKHAND_CLUSTERS[clean]) {
    return Array.from(new Set([inputLocation.trim(), ...JHARKHAND_CLUSTERS[clean]]));
  }

  for (const [key, cluster] of Object.entries(JHARKHAND_CLUSTERS)) {
    if (clean.includes(key) || key.includes(clean)) {
      return Array.from(new Set([inputLocation.trim(), ...cluster]));
    }
  }

  return [inputLocation.trim()];
}

// GET /api/search/locations - Distinct cities & localities
router.get('/locations', async (req, res) => {
  try {
    const locations = await db.query(`
      SELECT city, locality, COUNT(id) as count
      FROM blood_centers
      GROUP BY city, locality
      ORDER BY city, locality
    `);

    const jharkhandHubs = [
      { name: 'Ranchi', localities: ['Morabadi', 'Bariatu', 'Lalpur', 'Kantatoli', 'Firayalal', 'Khatal', 'Doranda'] },
      { name: 'Bokaro', localities: ['Sector 1', 'Sector 4', 'Sector 6', 'Sector 9', 'Sector 12', 'Chas'] },
      { name: 'Jamshedpur', localities: ['Bistupur', 'Sakchi', 'Telco', 'Kadma', 'Sonari'] },
      { name: 'Ramgarh', localities: ['Ramgarh Cantt', 'Subhash Chowk', 'Gola Road'] },
      { name: 'Deoghar', localities: ['Castairs Town', 'AIIMS Campus', 'Tower Chowk'] },
      { name: 'Hazaribagh', localities: ['Matwari', 'Korrah'] }
    ];

    return res.json({ success: true, jharkhandHubs, locations });
  } catch (err) {
    console.error('Error fetching search locations:', err);
    return res.status(500).json({ success: false, error: 'Could not retrieve locations' });
  }
});

// GET /api/search - Find centers with inventory & voluntary donors
router.get('/', async (req, res) => {
  try {
    const { bloodGroup, component, city, includeCompatible } = req.query;

    const cleanBloodGroup = (bloodGroup && bloodGroup.trim()) ? bloodGroup.trim() : 'O+';
    const cleanComponent = (component && component.trim() && component.trim().toLowerCase() !== 'all') ? component.trim() : null;
    const rawCity = (city && city.trim()) ? city.trim() : 'Ranchi';

    // 1. Resolve locality and city terms
    const locationTerms = resolveSearchTerms(rawCity);

    // 2. Compatibility mapping
    const targetGroups = (includeCompatible === 'true' && COMPATIBILITY_MAP[cleanBloodGroup])
      ? COMPATIBILITY_MAP[cleanBloodGroup]
      : [cleanBloodGroup];

    const groupPlaceholders = targetGroups.map(() => '?').join(', ');

    // 3. Dynamic SQL conditions for location terms
    const centerClauses = locationTerms.map(() => '(LOWER(c.city) LIKE ? OR LOWER(c.locality) LIKE ? OR LOWER(c.address) LIKE ?)').join(' OR ');
    const centerParams = [];
    locationTerms.forEach(term => {
      const p = `%${term.toLowerCase()}%`;
      centerParams.push(p, p, p);
    });

    // Query 1: Matching Blood Centers with inventory
    const compClause = cleanComponent ? 'AND i.component = ?' : '';
    const centerSql = `
      SELECT 
        c.id AS center_id,
        c.name AS center_name,
        c.city,
        c.locality,
        c.state,
        c.pincode,
        c.address,
        c.phone,
        c.email,
        c.operating_hours,
        c.latitude,
        c.longitude,
        i.blood_group,
        i.component,
        i.units_available,
        i.last_updated
      FROM blood_centers c
      JOIN blood_inventory i ON c.id = i.center_id
      WHERE (${centerClauses})
        ${compClause}
        AND i.blood_group IN (${groupPlaceholders})
        AND i.units_available > 0
      ORDER BY 
        CASE WHEN i.blood_group = ? THEN 0 ELSE 1 END,
        i.units_available DESC
    `;

    const finalCenterParams = cleanComponent
      ? [...centerParams, cleanComponent, ...targetGroups, cleanBloodGroup]
      : [...centerParams, ...targetGroups, cleanBloodGroup];

    const centerResults = await db.query(centerSql, finalCenterParams);

    // Query 2: Matching Voluntary Donors
    const donorClauses = locationTerms.map(() => '(LOWER(city) LIKE ? OR LOWER(locality) LIKE ? OR LOWER(address) LIKE ?)').join(' OR ');
    const donorParams = [];
    locationTerms.forEach(term => {
      const p = `%${term.toLowerCase()}%`;
      donorParams.push(p, p, p);
    });

    const donorSql = `
      SELECT id, name, phone, email, blood_group, city, locality, address, age, gender, latitude, longitude, is_verified, suspicious_reports_count
      FROM donors
      WHERE (${donorClauses})
        AND blood_group IN (${groupPlaceholders})
        AND is_available = 1
      ORDER BY 
        CASE WHEN blood_group = ? THEN 0 ELSE 1 END,
        is_verified DESC,
        created_at DESC
      LIMIT 15
    `;
    const finalDonorParams = [...donorParams, ...targetGroups, cleanBloodGroup];
    const matchingDonors = await db.query(donorSql, finalDonorParams);

    let finalDonors = matchingDonors;
    if (matchingDonors.length === 0) {
      const fallbackDonorSql = `
        SELECT id, name, phone, email, blood_group, city, locality, address, age, gender, latitude, longitude, is_verified, suspicious_reports_count
        FROM donors
        WHERE blood_group IN (${groupPlaceholders})
          AND is_available = 1
        ORDER BY 
          CASE WHEN blood_group = ? THEN 0 ELSE 1 END,
          is_verified DESC,
          created_at DESC
        LIMIT 10
      `;
      const fallbackDonorParams = [...targetGroups, cleanBloodGroup];
      finalDonors = await db.query(fallbackDonorSql, fallbackDonorParams);
    }

    // Query 3: Smart Regional Fallback if 0 centers found
    let nearbyCenters = [];
    let isFallback = false;

    if (centerResults.length === 0) {
      const fallbackSql = `
        SELECT 
          c.id AS center_id,
          c.name AS center_name,
          c.city,
          c.locality,
          c.state,
          c.pincode,
          c.address,
          c.phone,
          c.email,
          c.operating_hours,
          c.latitude,
          c.longitude,
          i.blood_group,
          i.component,
          i.units_available
        FROM blood_centers c
        JOIN blood_inventory i ON c.id = i.center_id
        WHERE 1=1
          ${compClause}
          AND i.blood_group IN (${groupPlaceholders})
          AND i.units_available > 0
        ORDER BY 
          CASE WHEN i.blood_group = ? THEN 0 ELSE 1 END,
          i.units_available DESC
        LIMIT 6
      `;
      const fallbackParams = cleanComponent
        ? [cleanComponent, ...targetGroups, cleanBloodGroup]
        : [...targetGroups, cleanBloodGroup];
      nearbyCenters = await db.query(fallbackSql, fallbackParams);
      if (nearbyCenters.length > 0) {
        isFallback = true;
      }
    }

    return res.json({
      success: true,
      query: {
        bloodGroup: cleanBloodGroup,
        component: cleanComponent || 'All',
        city: rawCity,
        locationTerms
      },
      isFallback,
      centersCount: centerResults.length,
      donorsCount: finalDonors.length,
      centers: centerResults,
      donors: finalDonors,
      nearbyCenters: isFallback ? nearbyCenters : []
    });
  } catch (err) {
    console.error('Search query error:', err);
    return res.status(500).json({ success: false, error: 'Database search error' });
  }
});

module.exports = router;


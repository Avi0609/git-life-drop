const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/centers - List all blood banks / centers
router.get('/', async (req, res) => {
  try {
    const { city, locality } = req.query;
    let sql = 'SELECT * FROM blood_centers WHERE 1=1';
    const params = [];

    if (city) {
      sql += ' AND LOWER(city) LIKE ?';
      params.push(`%${city.trim().toLowerCase()}%`);
    }

    if (locality) {
      sql += ' AND LOWER(locality) LIKE ?';
      params.push(`%${locality.trim().toLowerCase()}%`);
    }

    sql += ' ORDER BY city, name';
    const centers = await db.query(sql, params);

    return res.json({ success: true, count: centers.length, centers });
  } catch (err) {
    console.error('Error fetching centers:', err);
    return res.status(500).json({ success: false, error: 'Server error retrieving centers' });
  }
});

// GET /api/centers/:id - Get center with full inventory
router.get('/:id', async (req, res) => {
  try {
    const center = await db.get('SELECT * FROM blood_centers WHERE id = ?', [req.params.id]);
    if (!center) {
      return res.status(404).json({ success: false, error: 'Blood center not found' });
    }

    const inventory = await db.query(
      'SELECT id, blood_group, component, units_available, last_updated FROM blood_inventory WHERE center_id = ? ORDER BY blood_group, component',
      [req.params.id]
    );

    return res.json({ success: true, center, inventory });
  } catch (err) {
    console.error('Error fetching center details:', err);
    return res.status(500).json({ success: false, error: 'Server error retrieving center details' });
  }
});

// PATCH /api/centers/:id/inventory - Authorized hospital staff stock update
router.patch('/:id/inventory', async (req, res) => {
  try {
    const centerId = req.params.id;
    const { passcode, bloodGroup, component, units, updates } = req.body;
    const expectedPass = process.env.ADMIN_PASSCODE || '1234';

    if (passcode && passcode.toString().trim() !== expectedPass.toString().trim()) {
      return res.status(403).json({ success: false, error: 'Invalid hospital authorization passcode.' });
    }

    const center = await db.get('SELECT id, name FROM blood_centers WHERE id = ?', [centerId]);
    if (!center) {
      return res.status(404).json({ success: false, error: 'Blood center not found.' });
    }

    // Process bulk updates if provided
    if (Array.isArray(updates) && updates.length > 0) {
      for (const item of updates) {
        if (!item.bloodGroup || !item.component || item.units === undefined) continue;
        const existing = await db.get(
          'SELECT id FROM blood_inventory WHERE center_id = ? AND blood_group = ? AND component = ?',
          [centerId, item.bloodGroup.trim(), item.component.trim()]
        );
        if (existing) {
          await db.execute(
            'UPDATE blood_inventory SET units_available = ?, last_updated = CURRENT_TIMESTAMP WHERE id = ?',
            [Math.max(0, parseInt(item.units, 10)), existing.id]
          );
        } else {
          await db.execute(
            'INSERT INTO blood_inventory (center_id, blood_group, component, units_available) VALUES (?, ?, ?, ?)',
            [centerId, item.bloodGroup.trim(), item.component.trim(), Math.max(0, parseInt(item.units, 10))]
          );
        }
      }
      return res.json({ success: true, message: `Successfully updated stock units for ${center.name}.` });
    }

    // Process single item update
    if (!bloodGroup || !component || units === undefined) {
      return res.status(400).json({ success: false, error: 'bloodGroup, component, and units are required.' });
    }

    const existing = await db.get(
      'SELECT id FROM blood_inventory WHERE center_id = ? AND blood_group = ? AND component = ?',
      [centerId, bloodGroup.trim(), component.trim()]
    );

    if (existing) {
      await db.execute(
        'UPDATE blood_inventory SET units_available = ?, last_updated = CURRENT_TIMESTAMP WHERE id = ?',
        [Math.max(0, parseInt(units, 10)), existing.id]
      );
    } else {
      await db.execute(
        'INSERT INTO blood_inventory (center_id, blood_group, component, units_available) VALUES (?, ?, ?, ?)',
        [centerId, bloodGroup.trim(), component.trim(), Math.max(0, parseInt(units, 10))]
      );
    }

    return res.json({
      success: true,
      message: `Inventory updated: ${bloodGroup} (${component}) is now ${units} units at ${center.name}.`
    });
  } catch (err) {
    console.error('Error updating inventory:', err);
    return res.status(500).json({ success: false, error: 'Failed to update inventory.' });
  }
});

module.exports = router;


const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/camps - List upcoming blood donation camps
router.get('/', async (req, res) => {
  try {
    const { city } = req.query;
    let sql = 'SELECT * FROM blood_camps WHERE 1=1';
    const params = [];

    if (city) {
      sql += ' AND LOWER(city) LIKE ?';
      params.push(`%${city.trim().toLowerCase()}%`);
    }

    sql += ' ORDER BY camp_date ASC';
    const camps = await db.query(sql, params);

    return res.json({ success: true, count: camps.length, camps });
  } catch (err) {
    console.error('Error fetching blood camps:', err);
    return res.status(500).json({ success: false, error: 'Failed to retrieve donation camps' });
  }
});

// POST /api/camps/:id/register - Volunteer register for a donation camp
router.post('/:id/register', async (req, res) => {
  try {
    const { donorName, phone, bloodGroup } = req.body;
    if (!donorName || !phone) {
      return res.status(400).json({ success: false, error: 'Name and phone number are required to register for a camp.' });
    }

    // Increment registered donors count
    const campId = req.params.id;
    await db.execute('UPDATE blood_camps SET registered_donors_count = COALESCE(registered_donors_count, 0) + 1 WHERE id = ?', [campId]);

    return res.json({
      success: true,
      message: `Thank you ${donorName}! You are successfully pre-registered for this blood camp. Please arrive with a photo ID.`
    });
  } catch (err) {
    console.error('Error registering for camp:', err);
    return res.status(500).json({ success: false, error: 'Failed to register for camp' });
  }
});

module.exports = router;


const express = require('express');
const router = express.Router();
const db = require('../db');

// POST /api/reports - Report a suspicious donor or blood request
router.post('/', async (req, res) => {
  try {
    const { targetType, targetId, reportedName, reason, details, reporterContact } = req.body;

    if (!targetType || !targetId || !reportedName || !reason) {
      return res.status(400).json({
        success: false,
        error: 'Missing required report fields: targetType, targetId, reportedName, and reason are required.'
      });
    }

    // 1. Insert into suspicious_reports
    const sql = `
      INSERT INTO suspicious_reports (target_type, target_id, reported_name, reason, details, reporter_contact, status)
      VALUES (?, ?, ?, ?, ?, ?, 'Under Review')
    `;
    const params = [
      targetType.trim(),
      parseInt(targetId, 10),
      reportedName.trim(),
      reason.trim(),
      details ? details.trim() : null,
      reporterContact ? reporterContact.trim() : null
    ];

    const result = await db.execute(sql, params);

    // 2. Increment suspicious report count on target table
    if (targetType === 'donor') {
      await db.execute('UPDATE donors SET suspicious_reports_count = COALESCE(suspicious_reports_count, 0) + 1 WHERE id = ?', [targetId]);
    } else if (targetType === 'request') {
      await db.execute('UPDATE blood_requests SET suspicious_reports_count = COALESCE(suspicious_reports_count, 0) + 1 WHERE id = ?', [targetId]);
    }

    return res.status(201).json({
      success: true,
      reportId: result.insertId,
      message: 'Thank you for keeping LifeDrop safe. This profile has been flagged for investigation by our medical safety team.'
    });
  } catch (err) {
    console.error('Error recording suspicious report:', err);
    return res.status(500).json({ success: false, error: 'Server error processing report.' });
  }
});

// GET /api/reports - List flagged profiles and reports
router.get('/', async (req, res) => {
  try {
    const reports = await db.query('SELECT * FROM suspicious_reports ORDER BY created_at DESC LIMIT 50');
    return res.json({ success: true, count: reports.length, reports });
  } catch (err) {
    console.error('Error fetching reports:', err);
    return res.status(500).json({ success: false, error: 'Failed to retrieve reports' });
  }
});

// PATCH /api/reports/:id/status - Moderate a fraud report
router.patch('/:id/status', async (req, res) => {
  try {
    const reportId = req.params.id;
    const { status, banTarget, passcode } = req.body;
    const expectedPass = process.env.ADMIN_PASSCODE || '1234';

    if (passcode && passcode.toString().trim() !== expectedPass.toString().trim()) {
      return res.status(403).json({ success: false, error: 'Invalid admin authorization passcode.' });
    }

    if (!status) {
      return res.status(400).json({ success: false, error: 'Status is required (e.g. "Verified Fraud" or "Dismissed").' });
    }

    const report = await db.get('SELECT * FROM suspicious_reports WHERE id = ?', [reportId]);
    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found.' });
    }

    await db.execute('UPDATE suspicious_reports SET status = ? WHERE id = ?', [status, reportId]);

    // If verified fraud and banTarget is requested, disable the target donor or request
    if (status === 'Verified Fraud' || banTarget) {
      if (report.target_type === 'donor') {
        await db.execute('UPDATE donors SET is_available = 0, is_verified = 0 WHERE id = ?', [report.target_id]);
      } else if (report.target_type === 'request') {
        await db.execute('UPDATE blood_requests SET status = "Cancelled" WHERE id = ?', [report.target_id]);
      }
    }

    return res.json({
      success: true,
      message: `Report #${reportId} status updated to "${status}". Target moderation action applied.`
    });
  } catch (err) {
    console.error('Error updating report status:', err);
    return res.status(500).json({ success: false, error: 'Failed to update report status.' });
  }
});

module.exports = router;


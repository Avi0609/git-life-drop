const express = require('express');
const router = express.Router();
const db = require('../db');

// POST /api/requests - Submit an emergency blood requirement
router.post('/', async (req, res) => {
  try {
    const {
      patientName,
      bloodGroup,
      component,
      unitsNeeded,
      hospitalName,
      city,
      locality,
      contactName,
      contactPhone,
      urgency,
      latitude,
      longitude
    } = req.body;

    if (!patientName || !bloodGroup || !component || !hospitalName || !city || !contactPhone) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: patientName, bloodGroup, component, hospitalName, city, and contactPhone are required.'
      });
    }

    const sql = `
      INSERT INTO blood_requests (
        patient_name, blood_group, component, units_needed,
        hospital_name, city, locality, contact_name, contact_phone, urgency, status,
        latitude, longitude, suspicious_reports_count
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?, 0)
    `;

    const params = [
      patientName.trim(),
      bloodGroup.trim(),
      component.trim(),
      parseInt(unitsNeeded, 10) || 1,
      hospitalName.trim(),
      city.trim(),
      locality ? locality.trim() : city.trim(),
      contactName ? contactName.trim() : patientName.trim(),
      contactPhone.trim(),
      urgency || 'Normal',
      latitude ? parseFloat(latitude) : null,
      longitude ? parseFloat(longitude) : null
    ];

    const result = await db.execute(sql, params);

    return res.status(201).json({
      success: true,
      message: 'Urgent blood request broadcasted to registered donors and local blood centers.',
      requestId: result.insertId
    });
  } catch (err) {
    console.error('Error creating blood request:', err);
    return res.status(500).json({ success: false, error: 'Server error creating request.' });
  }
});

// GET /api/requests - List open blood requests
router.get('/', async (req, res) => {
  try {
    const { city, locality, bloodGroup, status } = req.query;
    let sql = 'SELECT * FROM blood_requests WHERE 1=1';
    const params = [];

    if (city) {
      sql += ' AND LOWER(city) LIKE ?';
      params.push(`%${city.trim().toLowerCase()}%`);
    }

    if (locality) {
      sql += ' AND LOWER(locality) LIKE ?';
      params.push(`%${locality.trim().toLowerCase()}%`);
    }

    if (bloodGroup) {
      sql += ' AND blood_group = ?';
      params.push(bloodGroup.trim());
    }

    if (status) {
      sql += ' AND status = ?';
      params.push(status.trim());
    } else {
      sql += " AND status = 'Open'";
    }

    sql += " ORDER BY CASE urgency WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 ELSE 3 END, created_at DESC";

    const requests = await db.query(sql, params);
    return res.json({ success: true, count: requests.length, requests });
  } catch (err) {
    console.error('Error fetching blood requests:', err);
    return res.status(500).json({ success: false, error: 'Server error retrieving requests.' });
  }
});

// PATCH /api/requests/:id/status - Update request status
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    if (!status || !['Open', 'Fulfilled', 'Cancelled'].includes(status)) {
      return res.status(400).json({ success: false, error: 'Status must be Open, Fulfilled, or Cancelled' });
    }

    const result = await db.execute('UPDATE blood_requests SET status = ? WHERE id = ?', [status, req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, error: 'Request not found' });
    }

    return res.json({ success: true, message: `Request status updated to ${status}` });
  } catch (err) {
    console.error('Error updating request status:', err);
    return res.status(500).json({ success: false, error: 'Server error updating status' });
  }
});

module.exports = router;

